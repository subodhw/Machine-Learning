import csv
import matplotlib.pyplot as plt
import math
import pandas as pd
import statistics

with open('A:\TY\Sem VI\ML\project RUL\Data\B005.csv') as csvfile:
    b1 = list(csv.DictReader(csvfile))
with open('A:\TY\Sem VI\ML\project RUL\Data\B006.csv') as csvfile:
    b2 = list(csv.DictReader(csvfile))
with open('A:\TY\Sem VI\ML\project RUL\Data\B007.csv') as csvfile:
    b3 = list(csv.DictReader(csvfile))

n = len(b1)
vol1 =[]
vol2=[]
vol3=[]
for i in b1:
    if 'VCE' not in i:
        i['VCE'] = (float(i['voltage'])**2/2)*float(i['time'])
    vol1.append(float(i['voltage']))
for i in b2:
    if 'VCE' not in i:
        i['VCE'] = (float(i['voltage'])**2/2)*float(i['time'])
    vol2.append(float(i['voltage']))
for i in b3:
    if 'VCE' not in i:
        i['VCE'] = (float(i['voltage'])**2/2)*float(i['time'])
    vol3.append(float(i['voltage']))

m1 = statistics.mean(vol1)
m2 = statistics.mean(vol2)
m3 = statistics.mean(vol3)
for i in b1:
    if 'VC_FI' not in i:
        i['VC_FI'] = (abs(float(i['voltage'])-m1)/n)*1000
for i in b2:
    if 'VC_FI' not in i:
        i['VC_FI'] = (abs(float(i['voltage'])-m2)/n)*1000
for i in b3:
    if 'VC_FI' not in i:
        i['VC_FI'] = (abs(float(i['voltage'])-m3)/n)*1000

noc = int(b1[-1]['Cycle'])
j = math.ceil(noc/4)
for i in b1:
    if int(i['Cycle'])<j:
        i['class']="A"
    elif   int(i['Cycle'])<2*j:
        i['class']="B"
    elif int(i['Cycle'])<3*j:
        i['class']="C"
    else:
        i['class']="D"
for i in b2:
    if int(i['Cycle'])<j:
        i['class']="A"
    elif   int(i['Cycle'])<2*j:
        i['class']="B"
    elif int(i['Cycle'])<3*j:
        i['class']="C"
    else:
        i['class']="D"
for i in b3:
    if int(i['Cycle'])<j:
        i['class']="A"
    elif   int(i['Cycle'])<2*j:
        i['class']="B"
    elif int(i['Cycle'])<3*j:
        i['class']="C"
    else:
        i['class']="D"

df1 = pd.DataFrame(b1)
df2 = pd.DataFrame(b2)
df3 = pd.DataFrame(b3)
df = pd.concat([df1,df2,df3],ignore_index=True)

X = df.drop(['class','time','voltage','Cycle','Time_at_temp_max','VCE'],axis='columns')
Y = df['class']

from sklearn.model_selection import train_test_split
X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.3)

from sklearn.svm import SVC
model = SVC(C=100)
model.fit(X_train,Y_train)

model.score(X_test,Y_test)

#      RUL Calculation
noc = int(b1[-1]['Cycle'])
for i in b1:
    if 'RUL' not in i and i['class']=='D':
        i['RUL']=((noc-int(i['Cycle']))/int(i['Cycle']))*100
for i in b2:
    if 'RUL' not in i and i['class']=='D':
        i['RUL']=((noc-int(i['Cycle']))/int(i['Cycle']))*100
for i in b3:
    if 'RUL' not in i and i['class']=='D':
        i['RUL']=((noc-int(i['Cycle']))/int(i['Cycle']))*100

df1 = pd.DataFrame([i for i in b1 if i['class']=="D" ])
df2 = pd.DataFrame([i for i in b2 if i['class']=="D" ])
df3 = pd.DataFrame([i for i in b3 if i['class']=="D" ])
df = pd.concat([df1,df2],ignore_index=True)

X = df3.drop(['RUL','class','time','voltage','Cycle','Time_at_temp_max','VCE'],axis='columns')
Y = df3['RUL']

from sklearn.model_selection import train_test_split
X_train,X_test,Y_train,Y_test = train_test_split(X,Y,test_size=0.4)

from sklearn.svm import SVR
model = SVR(C=500,kernel='rbf')
model.fit(X_train,Y_train)

model.score(X_test,Y_test)