import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import preprocessing

data = pd.read_json('B0018_discharge.json')
data = data.transpose()
data.reset_index(drop = True,inplace=True)
vmax = []
vmin = []
t1   = []
t2   = []
volt = data[['voltage_battery','time']]
for i in range(0,132):
    vmax.append(max(volt['voltage_battery'][i]))
    vmin.append(min(volt['voltage_battery'][i]))
    t2.append(volt['time'][i][volt['voltage_battery'][i].index(max(volt['voltage_battery'][i]))])
    t1.append(volt['time'][i][volt['voltage_battery'][i].index(min(volt['voltage_battery'][i]))])
    
data1 = pd.DataFrame(vmax,columns = ['V_max'])
data1['V_min'] = vmin
data1['Time_at_Vmin'] = t1
data1['Time_at_Vmax'] = t2

data1.to_csv('B0018.csv',index=False)